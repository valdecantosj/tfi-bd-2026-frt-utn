// ============================================================
// TP5 FitChain — Parte C: MongoDB y Persistencia Políglota
// Persona 2 — Colecciones: access_logs, equipment_iot, class_feedback
// Base de datos: fitchain
// ============================================================

use("fitchain");

// ============================================================
// C.1 — DISEÑO DE COLECCIONES (JSON Schema de validación)
// ============================================================

// ---------- 1) access_logs ----------
db.runCommand({
  collMod: "access_logs",
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["idSocio", "idSucursal", "tipoEvento", "timestamp"],
      properties: {
        idSocio: {
          bsonType: "int",
          description: "Referencia al idSocio de PostgreSQL"
        },
        idSucursal: {
          bsonType: "int",
          description: "Referencia al idSucursal de PostgreSQL"
        },
        idTorniquete: { bsonType: "string" },
        tipoEvento: {
          enum: ["check-in", "check-out"],
          description: "Tipo de evento de acceso"
        },
        timestamp: { bsonType: "date" },
        metodoAcceso: {
          enum: ["tarjeta", "huella", "app", "facial"]
        }
      }
    }
  },
  validationLevel: "strict",
  validationAction: "error"
});

// ---------- 2) equipment_iot ----------
db.createCollection("equipment_iot", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["idEquipo", "tipoEquipo", "timestamp"],
      properties: {
        idEquipo: {
          bsonType: "int",
          description: "Referencia al idEquipo de PostgreSQL"
        },
        tipoEquipo: {
          enum: ["cinta", "bicicleta", "eliptica", "rack_sentadillas",
                 "banco_olimpico", "juego_mancuernas"]
        },
        timestamp: { bsonType: "date" },
        horasUsoAcumuladas: { bsonType: ["double", "int"], minimum: 0 },
        ciclos: { bsonType: "int", minimum: 0 },
        lecturas: {
          bsonType: "object",
          description: "Estructura variable según tipoEquipo (ej: temperaturaMotor, vibracionMm_s, rpm)"
        }
      }
    }
  },
  validationLevel: "strict",
  validationAction: "error"
});

// ---------- 3) class_feedback ----------
db.createCollection("class_feedback", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["idClase", "idHorario", "idSocio", "fecha", "ratings"],
      properties: {
        idClase: { bsonType: "int" },
        idHorario: { bsonType: "int" },
        idSocio: { bsonType: "int" },
        idProfesor: { bsonType: "int" },
        fecha: { bsonType: "date" },
        ratings: {
          bsonType: "object",
          required: ["general"],
          properties: {
            general: { bsonType: "int", minimum: 1, maximum: 5 },
            limpieza: { bsonType: "int", minimum: 1, maximum: 5 },
            profesor: { bsonType: "int", minimum: 1, maximum: 5 },
            intensidad: { bsonType: "int", minimum: 1, maximum: 5 }
          }
        },
        comentario: { bsonType: "string" },
        preguntasAdicionales: {
          bsonType: "array",
          description: "Preguntas variables tipo encuesta libre"
        }
      }
    }
  },
  validationLevel: "strict"
});

// Verificación de los 3 schemas aplicados
db.getCollectionInfos({ name: "access_logs" });
db.getCollectionInfos({ name: "equipment_iot" });
db.getCollectionInfos({ name: "class_feedback" });


// ============================================================
// C.2 — OPERACIONES CRUD
// ============================================================

// ------------------------------------------------------------
// access_logs
// ------------------------------------------------------------

// 1) INSERT - insertOne
db.access_logs.insertOne({
  idSocio: 11,
  idSucursal: 3,
  idTorniquete: "TORN-03-A",
  tipoEvento: "check-in",
  timestamp: new Date("2026-07-15T08:05:00Z"),
  metodoAcceso: "app"
});

// 2) INSERT - insertMany
db.access_logs.insertMany([
  {
    idSocio: 11,
    idSucursal: 3,
    idTorniquete: "TORN-03-A",
    tipoEvento: "check-out",
    timestamp: new Date("2026-07-15T09:10:00Z"),
    metodoAcceso: "app"
  },
  {
    idSocio: 25,
    idSucursal: 1,
    idTorniquete: "TORN-01-B",
    tipoEvento: "check-in",
    timestamp: new Date("2026-07-15T18:00:00Z"),
    metodoAcceso: "huella"
  }
]);

// 3) FIND - filtro compuesto $and + $gte
db.access_logs.find({
  $and: [
    { idSucursal: 3 },
    { timestamp: { $gte: new Date("2026-07-15T00:00:00Z") } }
  ]
});

// 4) FIND - filtro compuesto $or + $regex
db.access_logs.find({
  $or: [
    { metodoAcceso: "app" },
    { idTorniquete: { $regex: "^TORN-01" } }
  ]
});

// 5) UPDATE - $set
db.access_logs.updateOne(
  { idSocio: 11, tipoEvento: "check-in", idTorniquete: "TORN-03-A" },
  { $set: { metodoAcceso: "facial" } }
);

// 6) DELETE - filtro condicional
// (con el set de prueba actual da deletedCount: 0, ver nota en el informe)
db.access_logs.deleteOne({
  idSocio: 25,
  tipoEvento: "check-in",
  timestamp: { $lt: new Date("2026-01-01T00:00:00Z") }
});


// ------------------------------------------------------------
// equipment_iot
// ------------------------------------------------------------

// 1) INSERT - insertOne
db.equipment_iot.insertOne({
  idEquipo: 45,
  tipoEquipo: "cinta",
  timestamp: new Date("2026-07-16T10:00:00Z"),
  horasUsoAcumuladas: 1230.5,
  ciclos: 8900,
  lecturas: { temperaturaMotorC: 42.3, velocidadKmh: 10.5, vibracionMmS: 1.2 }
});

// 2) INSERT - insertMany
db.equipment_iot.insertMany([
  {
    idEquipo: 20,
    tipoEquipo: "bicicleta",
    timestamp: new Date("2026-07-16T11:00:00Z"),
    horasUsoAcumuladas: 980.2,
    ciclos: 15300,
    lecturas: { rpm: 85, resistenciaNivel: 6 }
  },
  {
    idEquipo: 45,
    tipoEquipo: "cinta",
    timestamp: new Date("2026-07-16T12:00:00Z"),
    horasUsoAcumuladas: 1231.0,
    ciclos: 8950,
    lecturas: { temperaturaMotorC: 45.1, velocidadKmh: 12.0, vibracionMmS: 1.8 }
  }
]);

// 3) FIND - filtro compuesto $and + $gte
db.equipment_iot.find({
  $and: [
    { "lecturas.temperaturaMotorC": { $gte: 44 } },
    { horasUsoAcumuladas: { $gte: 1000 } }
  ]
});

// 4) FIND - filtro compuesto $or
db.equipment_iot.find({
  $or: [
    { tipoEquipo: "cinta" },
    { tipoEquipo: "eliptica" }
  ]
});

// 5) UPDATE - $inc + $set
db.equipment_iot.updateOne(
  { idEquipo: 45, timestamp: new Date("2026-07-16T12:00:00Z") },
  { $inc: { ciclos: 1 }, $set: { alertaMantenimiento: true } }
);

// 6) DELETE - filtro condicional
db.equipment_iot.deleteMany({ idEquipo: 20 });

// Verificación de la baja
db.equipment_iot.find({ idEquipo: 20 });


// ------------------------------------------------------------
// class_feedback
// ------------------------------------------------------------

// 1) INSERT - insertOne
db.class_feedback.insertOne({
  idClase: 1,
  idHorario: 5,
  idSocio: 13,
  idProfesor: 7,
  fecha: new Date("2026-07-14T19:00:00Z"),
  ratings: { general: 5, limpieza: 4, profesor: 5, intensidad: 4 },
  comentario: "Muy buena clase de Spinning, profesor motivador.",
  preguntasAdicionales: [
    { pregunta: "¿Recomendarías esta clase?", respuesta: "Sí" }
  ]
});

// 2) INSERT - insertMany
db.class_feedback.insertMany([
  {
    idClase: 2,
    idHorario: 8,
    idSocio: 4,
    idProfesor: 6,
    fecha: new Date("2026-07-14T20:00:00Z"),
    ratings: { general: 4, profesor: 4 },
    comentario: "Buena clase de Yoga, un poco corta."
  },
  {
    idClase: 3,
    idHorario: 12,
    idSocio: 19,
    idProfesor: 4,
    fecha: new Date("2026-07-15T07:00:00Z"),
    ratings: { general: 3, intensidad: 5 },
    comentario: "CrossFit muy intenso, faltó agua disponible."
  }
]);

// 3) FIND - filtro compuesto $and + $gte
db.class_feedback.find({
  $and: [
    { "ratings.general": { $lte: 3 } },
    { fecha: { $gte: new Date("2026-07-01T00:00:00Z") } }
  ]
});

// 4) FIND - filtro compuesto $or + $regex
db.class_feedback.find({
  $or: [
    { comentario: { $regex: "agua", $options: "i" } },
    { comentario: { $regex: "intenso", $options: "i" } }
  ]
});

// 5) UPDATE - $push
db.class_feedback.updateOne(
  { idSocio: 4, idClase: 2 },
  { $push: { preguntasAdicionales: { pregunta: "¿Volverías?", respuesta: "Sí" } } }
);

// 6) DELETE - filtro condicional
db.class_feedback.deleteOne({
  idSocio: 19,
  idClase: 3
});

